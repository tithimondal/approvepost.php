<?php
require('config.php');
if(isset($_GET['id'])){
    $id=$_GET['id'];
    // $status=1;
// }else{
//     $status=0;



$Uquery="UPDATE `blog` SET `status` = '1' WHERE `blog`.`id` = '$id' ";
$urun=mysqli_query($con,$Uquery);
// if($urun==true){
//     header("location:button.php");
// }
}
?>

