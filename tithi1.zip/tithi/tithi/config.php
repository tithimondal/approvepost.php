<?php
$con=mysqli_connect("localhost","root","","blog_web") ;

if($con == false){
    echo "<h1> server not connected try again..</h1>";
}

?>