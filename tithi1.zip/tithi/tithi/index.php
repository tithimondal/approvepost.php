<?php
include "header.php";
include "footer.php";
include "nav.php";
?>