<?php
include "header.php";
include "footer.php";
include "nav.php";

include "config.php";
// $query="SELECT * FROM blog ORDER BY id DESC";
// $db=mysqli_query($con,$query);

require('config.php');
$q="SELECT * FROM blog ORDER BY id DESC";
$db=mysqli_query($con,$q);






$q = mysqli_query($con,"SELECT * FROM blog WHERE status='1' ORDER BY id DESC ");
while($data = mysqli_fetch_array($q) ){
    ?>
    <a href="./singelpost.php ?id= <?=$data['id']?>">
    <div class= "col-md-3">

        <br><img src ="./image/<?php echo $data['img']?>" alt=""style="max-height:250px;">
          <h3>  <?php echo $data['titel']?></h3>
          <h6> Date: <?php echo $data['publish_date']?></h6>
          <h6> By<?php echo $data['author']?></h6>
          
          <p>
          <?php echo substr ($data['description'],0,80)?>..

        </p>
</div>
<?php
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <title class ="center"all post></title>
</head>
<body>
 <h1>ALL POST</h1>

 
</body>
</html>
<style>
  body {
  background-color:white ;
}

h1 {
  color: black;
  text-align: center;
}

p {
  font-family: verdana;
  font-size: 15px;
}
.col-md-3{
  margin:10px;
 
  float:left;
  width:300px;
  overflow:hidden;

}
.row .co-md-3{
  margin:50px;
  background:lightblue;
}
.row{
  display:inline-block;
}
   .center{
    text-align: center;
    float:left;
    padding: auto;
    margin:50px;
   }
</style>
<br>







