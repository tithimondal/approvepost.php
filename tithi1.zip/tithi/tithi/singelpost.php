
<?php

include "header.php";
include "footer.php";
include "nav.php";


$con =mysqli_connect("localhost","root","","blog_web");

$id=$_GET['id'];

$q = mysqli_query($con,"SELECT * FROM `blog`WHERE`id`='$id' ");
$data = mysqli_fetch_array($q);
?>


<section class ="destinations">
    
    <h3 class="titel"> <?php echo $data['titel'] ?> </h3>
    <h6>Date:  <?php echo $data['publish_date']?></h6>
   <h6> By <?php echo $data['author']?></h6>
    <div class="row">
        <img class="img" src="./image/<?php echo $data['img'] ?>"alt="" style="height:500px; width: 500px;">
        
        <?php echo $data['description'] ?>
        
        </div>
        </section>
        <style>
            
        .destinations{
            text-align:center;
            font-size:30px;
        }

        .img{
            position: center;
            padding: auto;
            margin: 20px;
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 50%;
          
            
        }
        </style>
        