<?php
require('config.php');

?>
    
    






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <title> Approve post</title>
</head>
<body>
 <h1 >Approve Post</h1>
 <div class= "col-md-3">

 <?php
    require('config.php');
    $q = mysqli_query($con,"SELECT * FROM blog WHERE status='0' ORDER BY id DESC ");
    while($data = mysqli_fetch_array($q) )
    {
    ?>
          <h2>Pending Post :</h2>
        <h3>  <?php echo $data['titel']?></h3>
          <h6> Date: <?php echo $data['publish_date']?></h6>
          <br><img src ="./image/<?php echo $data['img']?>" alt=""style="max-height:250px;"><br>
        
        <a style="text-decoration: none; padding: 2px 2px; color:white; background:black; border-radius:25px " href="update.php?id=<?= $data['id'] ?>">Approve</a>
    <?php
    }
    ?>

</div>
</body>
</html>
<style>
  body {
  background-color:  red;
}

.h1 {
  color: white;
  text-align: center;
 
}

p {
  font-family: verdana;
  font-size: 15px;
}
.col-md-3{
  margin:10px;
 
  float:left;
  width:300px;
  overflow:hidden;

}
.row .co-md-3{
  margin:50px;
  background:lightblue;
}
.row{
  display:inline-block;
}
.center{
  text-align: center;
  float:left;
  padding: auto;
  margin:50px;
}

</style>

