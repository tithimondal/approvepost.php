<?php
 include 'config.php';
 include 'header.php';
 include 'footer.php';



    
if(isset($_POST['submit']) ) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

  $q = mysqli_query($con, "INSERT INTO `contact` SET `name` ='$name',`email`='$email',`phone`='$phone' ");

  if($q == true){
      header("location:index.php");
  }



}  
?>
<div class="container">
<div class="row">
    <div class="col-xl-5 col-md-4 m-auto p-5 mt-5 bg-info">
        <form action="" method="POST">
        <h4 class= text-center>Contact Us</h4><br>
<div class="mb-3">
   Name:- <input type="name" name="name" placeholder="Name" class="form-control" required>
</div>
<div class="mb-3">
  Email:-  <input type="email" name="email" placeholder="Email" class="form-control" required>
</div>
<div class="mb-3">
Phon.Number:- <input type="phone" name="phone" placeholder="Phone Number" class="form-control" required>
</div>
<div class="mb-3">
   <input type="submit" name="submit"  class="btn btn-primary" value="Contact Us">
</div>
<div class="mb-3">
    
</div>


