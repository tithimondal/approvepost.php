<?php

 include 'config.php';
 include 'header.php';
 include 'footer.php';


//  session_start();

 if(isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    

 $q = mysqli_query($con, "INSERT INTO `user` SET `username` ='$username',`email`='$email',`password`='$password'  ");
 if($q == true ){
    header("location:login.php");
 }
 }
?>

<div class="container">
<div class="row">
    <div class="col-xl-5 col-md-4 m-auto p-5 mt-5 bg-info">
        <form action="" method="POST">
        <h4 class= text-center>REGISTER</h4><br>
        <div class="mb-3">
    <input type="username" name="username" placeholder="Username" class="form-control" required>
</div>
<div class="mb-3">
    <input type="email" name="email" placeholder="Email" class="form-control" required>
</div>
<div class="mb-3">
    <input type="password" name="password" placeholder="Password" class="form-control" required>
</div>
<div class="mb-3">
    <input type="submit" name="register"  class="btn btn-primary" value="Register">
</div>
</form>
 </div>
</div>
</div>
<style>
    .container{
        color:blue;
    }
</style>
