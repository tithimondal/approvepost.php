<?php
include "header.php";
include "footer.php";
include"nav.php"
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" >
</head>
<body class="bg-dark">
    <div class="container bg-light">
        <h1>Add POST</h1>
        <form action="" method="post"enctype="multipart/form-data">
            <p>TITLE </p>
            <input type="text" name="titel" id="titel" class="form-control" >
            <p>Author </p>
            <input type="text" name="author" id="author" class="form-control" >
            <p>IMAGE </p>
            <input type="file" name="img" id="img" class="form-control" accept="image/*">
            <p>DESCRIPTION </p>
            <textarea name="description" id="description" cols="30" rows="10" class="form-control"></textarea>

        <input type="submit"name="add" value="add post" class="btn btn-primary">
    
        

        </form>
    </div>
</body>
</html>
<?php
$con =mysqli_connect("localhost","root","","blog_web");
 
// session_start(); 

if(isset($_POST['add']) ) { 
    $titel= $_POST['titel'];
    $description = $_POST['description'];
    $author = $_POST['author'];
    // file
    $piname = $_FILES['img']['name'];
    $tmp = $_FILES['img']['tmp_name'];
    move_uploaded_file($tmp ,"./image/$piname");
  

    $q = mysqli_query($con, "INSERT INTO `blog` SET `titel` ='$titel',`description`='$description',`status`='0',`author`='$author',`img`='$piname' ");
    if($q== true) {
        // header("location:allblogs.php");
        ?>
        <script>
            alert("POST Added");

            
        </script>
        
        <?php
    }
}  




?>