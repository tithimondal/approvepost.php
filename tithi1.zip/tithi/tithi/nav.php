
 <?php
 session_start();
 
if(isset($_SESSION['login'])&& $_SESSION['login'] == true ){
$login=true;
}
else{
  $login=false;
}


echo'<nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="user-select: auto;">
  <div class="container-fluid" style="user-select: auto;">
    <a class="navbar-brand" href="#" style="user-select: auto;">Blog</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation" style="user-select: auto;">
      <span class="navbar-toggler-icon" style="user-select: auto;"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor02" style="user-select: auto;">
      <ul class="navbar-nav me-auto" style="user-select: auto;">
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link active" href="index.php" style="user-select: auto;">Home
            <span class="visually-hidden" style="user-select: auto;">(current)</span>
          </a>
        </li>
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="allblogs.php" style="user-select: auto;">All Blogs</a>
        </li>
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="contact.php" style="user-select: auto;">Contact</a>
        </li>';

        
        if($login){
        echo'<li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="add.php" style="user-select: auto;">Add Post</a>
        </li>
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="adminlogin.php" style="user-select: auto;">admin</a>
        </li>
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="logout.php" style="user-select: auto;">Logout</a>
        </li>';}
        if(!$login){
          echo'<li class="nav-item" style="user-select: auto;">
            <a class="nav-link" href="login.php" style="user-select: auto;">Login</a>
          </li>
          <li class="nav-item" style="user-select: auto;">
            <a class="nav-link" href="register.php" style="user-select: auto;">Register</a>
          </li>';}
      echo  
      '<form class="d-flex" style="user-select: auto;">
      
      </form>
    </div>
  </div>
</nav>';
?>