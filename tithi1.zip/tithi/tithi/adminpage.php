
<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Blog</title>
  </head>
  <body>


  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="user-select: auto;">
  <div class="container" style="user-select: auto;">
    <a class="navbar-brand" href="allblogs.php" style="user-select: auto;">Blog</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation" style="user-select: auto;">
      <span class="navbar-toggler-icon" style="user-select: auto;"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor02" style="user-select: auto;">
      <ul class="navbar-nav me-auto" style="user-select: auto;">
        <li class="nav-item" style="user-select: auto;">
          <!-- <a class="nav-link active" href="index.php" style="user-select: auto;">Home
            <span class="visually-hidden" style="user-select: auto;">(current)</span>
          </a>
        </li> -->
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link" href="button.php" style="user-select: auto;">Approve
          </a>
        </li>
        
        <li class="nav-item" style="user-select: auto;">
          <a class="nav-link active" href="logout.php" style="user-select: auto;">Logout
            <span class="visually-hidden" style="user-select: auto;">(current)</span>
          </a>
        </li>
      </ul>
      
      </form>
    </div>
  </div>
</nav>

